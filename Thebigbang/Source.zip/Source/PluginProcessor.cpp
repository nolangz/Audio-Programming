/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
ThebigbangAudioProcessor::ThebigbangAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#endif
{
}

ThebigbangAudioProcessor::~ThebigbangAudioProcessor()
{
}

//==============================================================================
const juce::String ThebigbangAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool ThebigbangAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool ThebigbangAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool ThebigbangAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double ThebigbangAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int ThebigbangAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int ThebigbangAudioProcessor::getCurrentProgram()
{
    return 0;
}

void ThebigbangAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String ThebigbangAudioProcessor::getProgramName (int index)
{
    return {};
}

void ThebigbangAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void ThebigbangAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // Use this method as the place to do any pre-playback
    // initialisation that you need..
    sr = sampleRate;
    
    sin1.setSampleRate(sampleRate);
    sin1.setFrequency(2.0f);
    
    sin2.setSampleRate(sampleRate);
    sin2.setFrequency(80.0f);
    
    sin3.setSampleRate(sampleRate);
    sin3.setFrequency(10.0f);
    
    sin4.setSampleRate(sampleRate);
    sin4.setFrequency(0.10f);
    
    sin5.setSampleRate(sampleRate);
    sin5.setFrequency(2.0f);
    
    sin6.setSampleRate(sampleRate);
    sin6.setFrequency(5.0f);
    
    am1.setcarry(sin1);
    am1.setmodulate(sin2);
    
    fm1.setcarry(sin3);
    fm1.setmodulate(sin4);
    
    pm1.setcarry(sin5);
    pm1.setmodulate(sin6);
    
    beat1.setlow(sin5);
    beat1.sethigh(sin5);
    
    
    juce::Reverb::Parameters reverbParams;
    reverbParams.dryLevel = 0.5f;
    reverbParams.wetLevel = 0.5f;
    reverbParams.roomSize = 0.99f;
    
    reverb.setParameters(reverbParams);
    
    reverb.reset();
    
}

void ThebigbangAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool ThebigbangAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void ThebigbangAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
    
    int numSamples = buffer.getNumSamples();
    float* leftChannel = buffer.getWritePointer(0); //left channel
    float* rightChannel = buffer.getWritePointer(1); //left channel
    
    // DSP LOOP
    for (int i=0; i<numSamples; i++)
    {
        
        float sample = pm1.process();
        
        leftChannel[i] = sample;
        rightChannel[i] = sample;
    }
    //reverb.processStereo(leftChannel, rightChannel, numSamples);

    // This is the place where you'd normally do the guts of your plugin's
    // audio processing...
    // Make sure to reset the state if your inner loop is processing
    // the samples and the outer loop is handling the channels.
    // Alternatively, you can process the samples with the channels
    // interleaved by keeping the same state.
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* channelData = buffer.getWritePointer (channel);

        // ..do something to the data...
    }
}

//==============================================================================
bool ThebigbangAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* ThebigbangAudioProcessor::createEditor()
{
    return new ThebigbangAudioProcessorEditor (*this);
}

//==============================================================================
void ThebigbangAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void ThebigbangAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ThebigbangAudioProcessor();
}
