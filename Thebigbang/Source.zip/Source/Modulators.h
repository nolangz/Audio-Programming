/*
  ==============================================================================

    Modulator.h
    Created: 24 Feb 2021 9:20:47pm
    Author:  赖锘林

  ==============================================================================
*/

#ifndef Modulatiors_h
#define Modulatiors_h

#include "Oscillators.h"

class Tuner
{
public:
    friend class Phasor;
    float process()
    {
        return output(carry,modulate);
    }
    
    virtual float output(SinOsc &carry, SinOsc &modulate)
    {
        return mag;
    }
    void setcarry(SinOsc car)
    {
        carry = car;
    }
    void setmodulate(SinOsc mod)
    {
        modulate = mod;
    }
    
private:
    SinOsc carry;
    SinOsc modulate;
    float mag;
};

// CHILD Class
class Amplitudemodulation : public Tuner
{
public:
    float output(SinOsc &carry, SinOsc &modulate) override
    {
        float s = (1+modulate.process()) * carry.process();
        return s;
    }
};

class Frequencymodulation : public Tuner
{
public:
    float output(SinOsc &carry, SinOsc &modulate) override
    {
        float freq = carry.getfrequency()+modulate.process();
        carry.setFrequency(freq);
        float s = carry.process();
        return s;
    }
};

class Phasemodulation : public Tuner
{
public:
    float output(SinOsc &carry, SinOsc &modulate) override
    {
        float p = ppa((modulate.process()+carry.getphase()*2*3.1415926536)/(2*3.1415926536));
        carry.setPhase(p);
        float s = carry.process();
        return s;
    }
    
    float ppa(float modulationphase)
    {
        float radian = (modulationphase-floor(modulationphase));
        return radian;
    }
};



#endif
