//
//  Oscillators.h
//  PointerTest
//
//  Created by tmudd on 06/02/2020.
//  Copyright © 2020 tmudd. All rights reserved.
//

#ifndef Oscillators_h
#define Oscillators_h

// PARENT phasor class
class Phasor
{
public:
    
    friend class Tuner;
    // Our parent oscillator class does the key things required for most oscillators:
    // -- handles phase
    // -- handles setters and getters for frequency and samplerate
    
    /// update the phase and output the next sample from the oscillator
    float process()
    {
        phase += phaseDelta;
        
        if (phase > 1.0f)
            phase -= 1.0f;
        
        return output(phase);
    }
    
    virtual float output(float p)
    {
        return p;
    }
    
    void setSampleRate(float SR)
    {
        sampleRate = SR;
    }
    void setFrequency(float freq)
    {
        frequency = freq;
        phaseDelta = frequency / sampleRate;
    }
    
    void setPhase(float newphase)
    {
        phase = newphase;
    }
    
    float getphase()
    {
        return phase;
    }
    
    float getfrequency()
    {
        return frequency;
    }
    
    float getsample()
    {
        return output(phase);
    }
    
private:
    float frequency;
    float sampleRate;
    float phase = 0.0f;
    float phaseDelta;
};
//==========================================


// CHILD Class
class TriOsc : public Phasor
{
public:
    float output(float p) override
    {
        return fabsf(p - 0.5f) - 0.5f;
    }
};


// CHILD Class
class SinOsc : public Phasor
{
public:
    float output(float p) override
    {
        return std::sin(p * 2.0 * 3.14159);
    }
};

class SquareOsc : public Phasor
{
public:

    float output(float p) override
    {
        float outVal = 0.5f;
        if(p > pulseWidth)
            outVal = -0.5f;
        
        return outVal;
    }
    
    float setPulseWidth(float pulseWidth)
    {
        this -> pulseWidth = std::fabs(pulseWidth) > 1 ? 1 : std::fabs(pulseWidth);
    }
    
private:
    float pulseWidth{0.5f};
    
};

#endif /* Oscillators_h */
