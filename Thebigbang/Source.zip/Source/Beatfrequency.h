/*
  ==============================================================================

    Beatfrequency.h
    Created: 25 Feb 2021 8:00:49pm
    Author:  赖锘林

  ==============================================================================
*/

#ifndef Beatfrequency_h
#define Beatfrequency_h

#include "Oscillators.h"

class Beatfreq
{
public:
    float process()
    {
        return 0.50f*low.process()+0.50f*high.process();
    }
    void setlow(SinOsc l)
    {
        low = l;
    }
    void sethigh(SinOsc h)
    {
        high = h;
    }
    
private:
    SinOsc low;
    SinOsc high;
};

#endif
